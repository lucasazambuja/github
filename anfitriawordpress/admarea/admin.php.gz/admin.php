<?php require_once('../wp-config.php'); 
$hostname_BLOG_MATRIZ = DB_HOST;
$database_BLOG_MATRIZ = DB_NAME;
$username_BLOG_MATRIZ = DB_USER;
$password_BLOG_MATRIZ = DB_PASSWORD;
$BLOG_MATRIZ = mysql_pconnect($hostname_BLOG_MATRIZ, $username_BLOG_MATRIZ, $password_BLOG_MATRIZ) or trigger_error(mysql_error(),E_USER_ERROR);
if (is_user_logged_in() == NULL){
    header('location: '.get_option('siteurl').'/admarea');
}
?>

<?php

if (!function_exists("GetSQLValueString")) {

function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 

{

  if (PHP_VERSION < 6) {

    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  }



  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);



  switch ($theType) {

    case "text":

      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";

      break;    

    case "long":

    case "int":

      $theValue = ($theValue != "") ? intval($theValue) : "NULL";

      break;

    case "double":

      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";

      break;

    case "date":

      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";

      break;

    case "defined":

      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;

      break;

  }

  return $theValue;

}

}



$editFormAction = $_SERVER['PHP_SELF'];

if (isset($_SERVER['QUERY_STRING'])) {

  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);

}



if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {

$content = $_POST['post_texto'];
$content = preg_replace('/<p>&nbsp;<\/p>/i', '', $content);
$content = preg_replace('/<p><\/p>/i', '', $content);
$content = preg_replace('/<br>/i', '', $content);
$content = preg_replace('/<\/p>/i', '</p><p>&nbsp;</p>', $content);
    
    $my_post = array(
  'post_title'    => iconv('latin1','utf8', $_POST['post_titulo']),
  'post_content'  => iconv('latin1','utf8', $content),
  'post_status'   => $_POST['post_status'],
  'post_author'   => 1,
  'post_category' => array($_POST['post_cat'],$_POST['post_sub'])
);
    
    $post_id = wp_insert_post($my_post);
    add_register_like($post_id, $_POST['post_tags']);

}







mysql_select_db($database_BLOG_MATRIZ, $BLOG_MATRIZ);

$query_categorias = "SELECT * FROM wp_terms WHERE term_id IN (SELECT term_id FROM wp_term_taxonomy WHERE parent = 0) ORDER BY name ASC";

$categorias = mysql_query($query_categorias, $BLOG_MATRIZ) or die(mysql_error());

$row_categorias = mysql_fetch_assoc($categorias);

$totalRows_categorias = mysql_num_rows($categorias);



$colname_mostra_categoria = "-1";

if (isset($_GET['categoria'])) {

  $colname_mostra_categoria = $_GET['categoria'];

}

mysql_select_db($database_BLOG_MATRIZ, $BLOG_MATRIZ);

$query_mostra_categoria = sprintf("SELECT * FROM wp_terms WHERE term_id = %s", GetSQLValueString($colname_mostra_categoria, "int"));

$mostra_categoria = mysql_query($query_mostra_categoria, $BLOG_MATRIZ) or die(mysql_error());

$row_mostra_categoria = mysql_fetch_assoc($mostra_categoria);

$totalRows_mostra_categoria = mysql_num_rows($mostra_categoria);



$colname_subcategoria = "-1";

if (isset($_GET['categoria'])) {

  $colname_subcategoria = $_GET['categoria'];

}

mysql_select_db($database_BLOG_MATRIZ, $BLOG_MATRIZ);

$query_subcategoria = sprintf("SELECT * FROM wp_terms WHERE `term_id` IN (SELECT term_id FROM wp_term_taxonomy WHERE parent = %s)", GetSQLValueString($colname_subcategoria, "text"));

$subcategoria = mysql_query($query_subcategoria, $BLOG_MATRIZ) or die(mysql_error());

$row_subcategoria = mysql_fetch_assoc($subcategoria);

$totalRows_subcategoria = mysql_num_rows($subcategoria);


mysql_select_db($database_BLOG_MATRIZ, $BLOG_MATRIZ);

$query_posts = "SELECT * FROM wp_posts WHERE post_type = 'post' and post_status != 'trash' ORDER BY ID DESC";

$posts = mysql_query($query_posts, $BLOG_MATRIZ) or die(mysql_error());

$row_posts = mysql_fetch_assoc($posts);

$totalRows_posts = mysql_num_rows($posts);

?>

<html>

<head>

<title>htmlArea Example</title>

<style type="text/css">

<!--

body, td {

	font-family: arial;

	font-size: x-small;

}

a {

	color: #0000BB;

	text-decoration: none;

}

a:hover {

	color: #FF0000;

	text-decoration: underline;

}

.headline {

	font-family: arial black, arial;

	font-size: 28px;

	letter-spacing: -1px;

}

.headline2 {

	font-family: verdana, arial;

	font-size: 12px;

}

.subhead {

	font-family: arial, arial;

	font-size: 18px;

	font-weight: bold;

	font-style: italic;

}

.backtotop {

	font-family: arial, arial;

	font-size: xx-small;

}

.code {

	background-color: #EEEEEE;

	font-family: Courier New;

	font-size: x-small;

	margin: 5px 0px 5px 0px;

	padding: 5px;

	border: black 1px dotted;

}

font {

	font-family: arial black, arial;

	font-size: 28px;

	letter-spacing: -1px;

}

-->

</style>

<script language="Javascript1.2"><!-- // load htmlarea

_editor_url = "";                     // URL to htmlarea files

var win_ie_ver = parseFloat(navigator.appVersion.split("MSIE")[1]);

if (navigator.userAgent.indexOf('Mac')        >= 0) { win_ie_ver = 0; }

if (navigator.userAgent.indexOf('Windows CE') >= 0) { win_ie_ver = 0; }

if (navigator.userAgent.indexOf('Opera')      >= 0) { win_ie_ver = 0; }

if (win_ie_ver >= 5.5) {

  document.write('<scr' + 'ipt src="' +_editor_url+ 'editor.js"');

  document.write(' language="Javascript1.2"></scr' + 'ipt>');  

} else { document.write('<scr'+'ipt>function editor_generate() { return false; }</scr'+'ipt>'); }

// --></script>

<link rel="stylesheet" href="../stylesheet.css" type="text/css" charset="utf-8">

<style type="text/css" media="screen">

.style3 {

	font: 14px 'MuliRegular', Arial, sans-serif;

}

.style4 {

	font: 25px 'MuliRegular', Arial, sans-serif;

}

.style5 {

	font: 16px 'MuliRegular', Arial, sans-serif;
	letter-spacing:1px;

}

.Maiusc {

	font: 14px 'MuliRegular', Arial, sans-serif;

	text-transform: uppercase;

}

#container {

	width: 900px;

	margin-left: auto;

	margin-right: auto;

	margin-top: 0px;

}

body {

	background-image: url(bg1.gif);

}

img.img {

	padding: 10px;

	width:500px;

}

</style>

</head>

<body>

<div align=center> <span class="headline">&Aacute;rea Administrativa do Blog Anfitri&atilde;</span><span class="headline2"><br>

  </span>

  <hr>

</div>

<table width="100%" border="0" cellspacing="3" cellpadding="3">

  

    <tr>

      <td valign="middle" nowrap><span class="Maiusc">Selecione uma Categoria:</span></td>

      <td valign="middle">&nbsp;</td>

      <td valign="middle"><span class="Maiusc">ALTERAR POST:</span></td>

    </tr>

    <tr><form name="form2" method="get" action="">

      <td width="16%" valign="middle"><select name="categoria" class="style4" id="categoria" onChange="submit()" style="text-transform:uppercase">

          <option></option>

          <?php

do {  

?>

          <option value="<?php echo $row_categorias['term_id']?>"<?php if (!(strcmp($row_categorias['term_id'], $_GET['categoria']))) {echo "selected=\"selected\"";} ?>><?php echo $row_categorias['name']?></option>

          <?php

} while ($row_categorias = mysql_fetch_assoc($categorias));

  $rows = mysql_num_rows($categorias);

  if($rows > 0) {

      mysql_data_seek($categorias, 0);

	  $row_categorias = mysql_fetch_assoc($categorias);

  }

?>

        </select></td></form>

      <td width="36%" valign="middle"><a href="cat.php" target="painel" class="style5">Criar Categoria</a></td>

      <form name="form3" method="get" action="alterar.php"><td width="48%" valign="middle"><select name="alterar" class="style4" onChange="submit()" style="text-transform:uppercase; width:98%">

        <option>SELECIONE </option>

<?php
global $wpdb;
do {  
    $category = $wpdb->get_var('SELECT term_taxonomy_id FROM wp_term_relationships where object_id = '.$row_posts['ID'].' LIMIT 1');
?>
        <option value="<?php echo $row_posts['ID']?> <?php echo $category?>"><?php echo $row_posts['post_title']?></option>

        <?php

} while ($row_posts = mysql_fetch_assoc($posts));

  $rows = mysql_num_rows($posts);

  if($rows > 0) {

      mysql_data_seek($posts, 0);

	  $row_posts = mysql_fetch_assoc($posts);

  }

?>

      </select>

          </td></form>

    </tr>

  

</table>

<table width="100%" border="0" cellspacing="3" cellpadding="3">

  <!-- SUMIR TR -->

  

    <tr>

      <td width="52%" align="left" valign="top"><form method="post" name="form1" action="<?php echo $editFormAction; ?>">

          <input name="post_cat" type="hidden" id="post_cat" value="<?php echo $_GET['categoria']; ?>">

         <?php if ($totalRows_mostra_categoria > 0) { // Show if recordset not empty ?>

         <!-- SUMIR TR -->

          <table width="87%" align="center">

            <tr valign="baseline">

              <td valign="middle"><strong class="style4" style="text-transform:uppercase"><span class="Maiusc">Categoria Escolhida:</span><br>

                <?php echo $row_mostra_categoria['name']; ?></strong>

                <?php if ($totalRows_subcategoria == 0) { // Show if recordset empty ?>

                  <a href="sub.php?categoria=<?php echo $_GET['categoria']; ?>" target="painel" class="style5">[Criar Sub Categoria]</a>

              <?php } // Show if recordset empty ?></td>

            </tr>

            <tr valign="baseline">

<?php if ($totalRows_subcategoria > 0) { // Show if recordset not empty ?>

                <td><span class="Maiusc">sub categoria:</span><br>

                  <select name="post_sub" class="style4" id="combo2" style="text-transform:uppercase">

                    <?php

do {  

?>

                    <option value="<?php echo $row_subcategoria['term_id']?>"><?php echo $row_subcategoria['name']?></option>

                    <?php

} while ($row_subcategoria = mysql_fetch_assoc($subcategoria));

  $rows = mysql_num_rows($subcategoria);

  if($rows > 0) {

      mysql_data_seek($subcategoria, 0);

	  $row_subcategoria = mysql_fetch_assoc($subcategoria);

  }

?>

                  </select>

                  <a href="sub.php?categoria=<?php echo $_GET['categoria']; ?>" target="painel" class="style5">[Criar Sub Categoria]</a></td>

                <?php } // Show if recordset not empty ?>

            </tr>

            <tr valign="baseline">

              <td class="Maiusc">Colunista</td>

            </tr>

            <tr valign="baseline">

            </tr>

            <tr valign="baseline">

              <td class="Maiusc">Titulo do post</td>

            </tr>

            <tr valign="baseline">

              <td><input name="post_titulo" type="text" class="Maiusc" style="width:650; font-size:26px;" value="" size="32"></td>

            </tr>

            <tr valign="baseline">

              <td class="Maiusc">Texto do post</td>

            </tr>

            <tr valign="baseline">

              <td><textarea name="post_texto" cols="50" rows="5" ></textarea></td>

            </tr>

            <tr valign="baseline">

              <td class="Maiusc"><table width="100%" border="0" cellpadding="2">
                <tr>
                  <td width="5%"><img src="../taca.gif" width="25" height="25"></td>
                  <td width="5%"><input name="post_tags" type="text" class="Maiusc" value="2" size="4"></td>
                  <td width="90%">GOSTARAM</td>
                </tr>
              </table></td>

            </tr>

            <tr valign="baseline">

              <td>&nbsp;</td>

            </tr>

            <tr valign="baseline">

              <td class="Maiusc">Status</td>

            </tr>

            <tr valign="baseline">

              <td><select name="post_status" class="Maiusc">

                  <option value="publish">Publicar</option>

                  <option value="draft" selected>Rascunho</option>

                </select></td>

            </tr>

            <tr valign="baseline">

              <td><input type="submit" value="ENVIAR POST"></td>

            </tr>

          </table>

          

          

          <input type="hidden" name="post_data" value="<?php echo date('Y-m-d'); ?>">

          <input type="hidden" name="MM_insert" value="form1">

          <input type="hidden" name="post_id" value="<?php echo time(); ?>">

        </form>

        <!-- SUMIR TR -->

         <?php } // Show if recordset not empty ?>

        </td>

      <td width="48%" valign="bottom"><table width="99%" border="0" cellspacing="5" cellpadding="5">
        <tr>
          <td width="25%" height="0" align="center" nowrap bgcolor="#000000" class="Maiusc"><a href="comments.php" style="color:#FFF" target="_blank"><strong>ver comments</strong></a></td>
          <td width="17%" height="0" align="center" nowrap bgcolor="#000000" class="Maiusc"><a href="destaque.php" style="color:#FFF" target="painel"><strong>DESTAQUE</strong></a></td>
          <td width="11%" height="0" align="center" nowrap bgcolor="#000000" class="Maiusc"><a href="links.php" style="color:#FFF" target="painel"><strong>LINKS</strong></a></td>
          <td width="12%" height="0" align="center" nowrap bgcolor="#000000" class="Maiusc"><a href="fotos.php" style="color:#FFF" target="painel"><strong>FOTOS</strong></a></td>
        </tr>
        <tr>
          <td width="21%" height="0" align="center" nowrap bgcolor="#000000" class="Maiusc"><a href="https://www.google.com/analytics/web/#report/visitors-overview/a28143970w53758072p54638076/" style="color:#FFF" target="_blank"><strong>Estatistica</strong></a></td>
          <td width="14%" height="0" align="center" nowrap bgcolor="#000000" class="Maiusc"><a href="files/bkp.php" style="color:#FFF" target="painel"><strong>Backup</strong></a></td>
          <td width="14%" height="0" align="center" nowrap bgcolor="#000000" class="Maiusc"><a href="sorteio_cfg.php" style="color:#FFF" target="painel"><strong>SORTEIO</strong></a></td>
          <td width="14%" height="0" align="center" nowrap bgcolor="#000000" class="Maiusc"><a href="tabelao.php" style="color:#FFF" target="_blank"><strong>TABELA</strong></a></td>
        </tr>
      </table>
        <br>

<iframe name="painel" id="painel" height="700" width="100%" frameborder="1" src="iframe.php?pagina_iframe=fotos&pagina=1&logo=marca"></iframe>

        <br>

        COLE E COPIE:<br>

        <textarea name="textarea" id="textarea" cols="45" rows="25" style="width:90%"></textarea></td>

    </tr>

   

  <!-- SUMIR TR -->

</table>

<p>&nbsp;</p>

<script language="javascript1.2">

var config = new Object();    // create new config object



config.width = "650px";

config.height = "800px";

config.bodyStyle = 'background-color: white; font-family: "Verdana"; font-size: x-small;';

config.debug = 0;



// NOTE:  You can remove any of these blocks and use the default config!



config.toolbar = [

    ['fontname'],

    ['fontsize'],

    ['fontstyle'],

    ['linebreak'],

    ['bold','italic','underline','separator'],

//  ['strikethrough','subscript','superscript','separator'],

    ['justifyleft','justifycenter','justifyright','separator'],

    ['OrderedList','UnOrderedList','Outdent','Indent','separator'],

    ['forecolor','backcolor','separator'],

    ['HorizontalRule','Createlink','InsertImage','htmlmode','separator'],

    ['about','help','popupeditor'],

];



config.fontnames = {

    "Arial":           "arial, helvetica, sans-serif",

    "Courier New":     "courier new, courier, mono",

    "Georgia":         "Georgia, Times New Roman, Times, Serif",

    "Tahoma":          "Tahoma, Arial, Helvetica, sans-serif",

    "Times New Roman": "times new roman, times, serif",

    "Verdana":         "Verdana, Arial, Helvetica, sans-serif",

    "impact":          "impact",

    "WingDings":       "WingDings"

};

config.fontsizes = {

    "1 (8 pt)":  "1",

    "2 (10 pt)": "2",

    "3 (12 pt)": "3",

    "4 (14 pt)": "4",

    "5 (18 pt)": "5",

    "6 (24 pt)": "6",

    "7 (36 pt)": "7"

  };



//config.stylesheet = "http://www.domain.com/sample.css";

  

config.fontstyles = [   // make sure classNames are defined in the page the content is being display as well in or they won't work!

  { name: "TITULO", className: "style4", classStyle: "font: 25px 'CaviarDreamsBold', Arial, sans-serif;" },

  { name: "CAVIAR",     className: "style5",  classStyle: "font: 15px 'CaviarDreamsRegular', Arial, sans-serif;" },

  { name: "MAIUSCULA",    className: "Maiusc", classStyle: "font: 14px 'CaviarDreamsBold', Arial, sans-serif; text-transform: uppercase;" }





// leave classStyle blank if it's defined in config.stylesheet (above), like this:

//  { name: "verdana blue", className: "headline4", classStyle: "" }  

];



editor_generate('post_texto',config);

</script>

</body>

</html>

<?php

mysql_free_result($categorias);



mysql_free_result($mostra_categoria);



mysql_free_result($subcategoria);



mysql_free_result($posts);

?>